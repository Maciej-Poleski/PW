
int cuMin(int* T, int n);
