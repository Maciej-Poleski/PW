
int cuMin(int* T, int n) __attribute__((optimize(3)));
