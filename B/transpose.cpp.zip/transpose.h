


int* transpose(int* matrix, int height, int width);

